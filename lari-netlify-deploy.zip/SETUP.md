# Lari Creative Studio: forms to email (Netlify + Resend)

Folder contents
- index.html  (the site; forms now post to /.netlify/functions/send-enquiry)
- netlify.toml
- netlify/functions/send-enquiry.js

## 1. Resend
1. Create an account at resend.com and add the domain laricreativestudio.com.
2. Add the DNS records Resend shows (SPF and DKIM) at your domain host, then click Verify.
3. Create an API key with "Sending access" only. Copy it once.

## 2. Netlify environment variables
Site configuration > Environment variables > add:
- RESEND_API_KEY = (your Resend key)
- TO_EMAIL = hello@laricreativestudio.com   (make sure this inbox receives mail)
- FROM_EMAIL = Lari Creative Studio <forms@laricreativestudio.com>
- SITE_ORIGINS = https://laricreativestudio.com,https://www.laricreativestudio.com  (optional; this is the default)
Never put the key in index.html or commit it to Git.

## 3. Deploy
Put this whole folder in a Git repo connected to Netlify, or run `npx netlify deploy --prod` from this folder.
(Drag-and-drop of a single HTML file does NOT deploy functions.)
Then check Site > Functions: "send-enquiry" should be listed.

## 4. Test
Submit the Contact form, the Start a Project form and the footer newsletter box.
Each should arrive at TO_EMAIL, and replying answers the visitor.
If a send fails, the page opens the visitor's email app as a fallback.
Check Functions > send-enquiry > Logs for errors (a 403 usually means the domain is missing from SITE_ORIGINS; a 502 means a Resend key or FROM domain problem).
