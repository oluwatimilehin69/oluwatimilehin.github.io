// Netlify Function: receives site forms and emails them to the studio via Resend.
// Secrets are read from Netlify environment variables and never reach the browser.
// Required env vars: RESEND_API_KEY, TO_EMAIL, FROM_EMAIL
// Optional: SITE_ORIGINS (comma-separated, default below)

const ORIGINS = (process.env.SITE_ORIGINS ||
  'https://laricreativestudio.com,https://www.laricreativestudio.com').split(',').map(s => s.trim());
const hits = new Map(); // best-effort rate limit per warm instance

const clean = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]+/g, ' ').trim().slice(0, n);
const multi = (v, n) => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, n);
const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const okEmail = e => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) && e.length <= 254;

const reply = (code, body, origin) => ({
  statusCode: code,
  headers: {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': origin || ORIGINS[0],
    'Vary': 'Origin',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  },
  body: JSON.stringify(body)
});

exports.handler = async (event) => {
  const origin = event.headers.origin || event.headers.Origin || '';
  const allowed = ORIGINS.includes(origin);
  if (event.httpMethod === 'OPTIONS') return reply(allowed ? 204 : 403, {}, allowed ? origin : '');
  if (event.httpMethod !== 'POST') return reply(405, { ok: false, error: 'method' }, origin);
  if (!allowed) return reply(403, { ok: false, error: 'origin' }, '');
  if ((event.body || '').length > 20000) return reply(413, { ok: false, error: 'size' }, origin);

  // rate limit: 5 submissions per 10 minutes per IP
  const ip = (event.headers['x-nf-client-connection-ip'] || event.headers['x-forwarded-for'] || 'x').split(',')[0].trim();
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter(t => now - t < 600000);
  if (recent.length >= 5) return reply(429, { ok: false, error: 'rate' }, origin);
  recent.push(now); hits.set(ip, recent);

  let d;
  try { d = JSON.parse(event.body || '{}'); } catch (e) { return reply(400, { ok: false, error: 'json' }, origin); }
  if (d.hp) return reply(200, { ok: true }, origin); // honeypot: pretend success to bots

  const type = clean(d.type, 20);
  const email = clean(d.email, 254);
  if (!okEmail(email)) return reply(400, { ok: false, error: 'email' }, origin);

  let subject, rows;
  if (type === 'contact') {
    const name = clean(d.name, 100), msg = multi(d.message, 4000);
    if (!name || msg.length < 10) return reply(400, { ok: false, error: 'fields' }, origin);
    subject = `Website message from ${name}`;
    rows = [['Name', name], ['Email', email], ['Phone', clean(d.phone, 30) || '-'], ['Message', msg]];
  } else if (type === 'project') {
    const name = clean(d.name, 100);
    if (!name) return reply(400, { ok: false, error: 'fields' }, origin);
    subject = `New project enquiry from ${name}`;
    rows = [['Name', name], ['Email', email], ['Service', clean(d.service, 120) || 'Not sure yet'], ['Package', clean(d.package, 30) || 'Not sure'], ['Budget', clean(d.budget, 80) || '-'], ['Message', multi(d.message, 4000) || '-']];
  } else if (type === 'newsletter') {
    subject = 'New Studio notes subscriber';
    rows = [['Email', email]];
  } else {
    return reply(400, { ok: false, error: 'type' }, origin);
  }

  const text = rows.map(r => `${r[0]}: ${r[1]}`).join('\n');
  const html = `<div style="font-family:Arial,sans-serif;color:#111827"><h2 style="margin:0 0 12px;color:#081F33">${esc(subject)}</h2><table cellpadding="8" style="border-collapse:collapse">${rows.map(r => `<tr><td style="border-bottom:1px solid #e2ddd2;color:#5b6472;vertical-align:top"><b>${esc(r[0])}</b></td><td style="border-bottom:1px solid #e2ddd2;white-space:pre-wrap">${esc(r[1])}</td></tr>`).join('')}</table><p style="color:#5b6472;font-size:12px">Sent from laricreativestudio.com. Reply to this email to answer the sender.</p></div>`;

  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.FROM_EMAIL, to: [process.env.TO_EMAIL], reply_to: email, subject, html, text })
    });
    if (!r.ok) { console.error('Resend error', r.status, await r.text()); return reply(502, { ok: false, error: 'send' }, origin); }
    return reply(200, { ok: true }, origin);
  } catch (e) {
    console.error(e);
    return reply(502, { ok: false, error: 'send' }, origin);
  }
};
